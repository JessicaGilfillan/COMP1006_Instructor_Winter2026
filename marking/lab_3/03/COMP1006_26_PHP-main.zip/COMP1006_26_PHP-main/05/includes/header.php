
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Week 4 - Form Validation </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <link href="styles/main.css" rel="stylesheet">
</head>

<body>
    <header>
        <h1 class="site-title">
            <img
                src="assets/bitumi.png"
                alt="Bake It Til You Make It Bakery"
                class="logo">
        </h1>
        <nav>
            <a href="/"> Home </a>
            <a href="#"> About </a>
            <a href="#"> Order Online </a>
            <a href="#"> Contact </a>
        </nav>
    </header>